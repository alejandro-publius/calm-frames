# Calm Frames submission draft

Prepared October 13, 2026 from commit `7444d21a7d554f36f369396f12cc6f06a95bd70c`.
This is a writing, design and recording packet. It is not a new native package,
finished video or submitted entry.

Start with `01-project-description.md` for the project story and
`02-fields-and-links.md` for the other planned form fields. The latter includes
working notes; copy only the requested field into Devpost. Confirm the live
form's field names and limits before pasting. Contact details remain outside
this packet.

The gallery contains browser design previews of the current cinematic layout.
Caption them "Browser design preview; native Vega capture pending" if used in a
gallery. They do not establish native playback. The brand folder contains the
approved icons and listing tile, with the asset ledger and notices included.

Use `guides/MAC_FINISH.md` for the remaining Mac work and
`guides/VIDEO_SCRIPT.md` for the next 2:36 recording plan. Fill every blank in
`capture-plan.template.json` from the new capture session before assembly.
The original verification reports are still required for the packaged library;
they were not in the earlier review archive. Preserve the strict release gate.

Remaining: current Vega build and observations, matching native demo and
finished-file checks, publication license/security decisions, actual external
links, and approved publication and Devpost submission. The saved earlier native
package and video remain separate historical assets on the draft release.

The source documents are at:
https://github.com/alejandro-publius/calm-frames/blob/7444d21a7d554f36f369396f12cc6f06a95bd70c/docs/COMPLETION_CHECKLIST.md

Links in the copied guides point to the exact source commit on GitHub and need
repository access. `manifest.json` records each file's source and SHA-256.
Numeric evidence markers were removed from the copy while retaining their values.
